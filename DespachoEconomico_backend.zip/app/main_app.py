# =============================================================
# ARCHIVO: app/main_app.py
# USO: streamlit run app/main_app.py
# PROPÓSITO: Interfaz principal del simulador de despacho.
# TU EQUIPO: Conecta sus páginas importando desde src/
# =============================================================
import sys
sys.path.insert(0, '.')

import streamlit as st
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

from src.cenace.cenace_client import get_demanda_total_sistema
from src.model.pypsa_model import correr_despacho_completo, cargar_capacidades
from src.scenarios.scenarios import ESCENARIOS, aplicar_escenario, listar_escenarios

st.set_page_config(
    page_title="Despacho Económico — México",
    page_icon="⚡",
    layout="wide"
)

st.title("⚡ Simulador de Despacho Económico")
st.caption("Sistemas aislados: BCS · BCA · SIN | Datos reales CENACE | PyPSA + HiGHS")

# ── Sidebar: parámetros ────────────────────────────────────────────
with st.sidebar:
    st.header("🎛️ Parámetros")

    fecha_ini = st.date_input("Fecha inicio", value=pd.Timestamp("2024-06-01"))
    fecha_fin = st.date_input("Fecha fin",    value=pd.Timestamp("2024-06-07"))

    sistemas = st.multiselect(
        "Sistemas", ["BCS", "BCA", "SIN"],
        default=["BCS", "BCA", "SIN"]
    )

    st.divider()
    st.subheader("📋 Escenario")
    opciones = [("base", "🔵 Base (sin cambios)")] + listar_escenarios()
    clave_esc = st.selectbox(
        "Selecciona escenario",
        options=[c for c,_ in opciones],
        format_func=lambda c: dict(opciones)[c]
    )

    if clave_esc != "base" and clave_esc in ESCENARIOS:
        esc = ESCENARIOS[clave_esc]
        st.info(esc["descripcion"])
        st.success(f"💡 {esc['lección']}")

    correr = st.button("▶️ Correr Despacho", type="primary", use_container_width=True)

# ── Área principal ─────────────────────────────────────────────────
if correr:
    if not sistemas:
        st.error("Selecciona al menos un sistema.")
        st.stop()

    fi = fecha_ini.strftime("%Y-%m-%d")
    ff = fecha_fin.strftime("%Y-%m-%d")

    # 1. Descargar demanda
    st.subheader("📡 Descargando datos CENACE...")
    demandas = {}
    cols = st.columns(len(sistemas))
    for i, s in enumerate(sistemas):
        with cols[i]:
            with st.spinner(f"Descargando {s}..."):
                df = get_demanda_total_sistema(s, fi, ff)
                if df.empty:
                    st.error(f"{s}: Sin datos")
                else:
                    demandas[s] = df['total_cargas_mw'].reset_index(drop=True)
                    st.metric(f"{s} — Pico", f"{demandas[s].max():.0f} MW")

    if not demandas:
        st.error("No hay datos disponibles.")
        st.stop()

    # 2. Aplicar escenario y resolver
    cap = cargar_capacidades("2024")
    costos_override = None
    voll = 5000.0
    año_cap = "2024"

    if clave_esc != "base":
        params = aplicar_escenario(clave_esc, cap)
        costos_override = params.get("costos_override")
        voll = params.get("voll", 5000.0)
        año_cap = params.get("año_capacidad", "2024")
        cap = params.get("capacidades_modificadas", cap)

    st.subheader("⚙️ Resolviendo optimización...")
    with st.spinner("PyPSA + HiGHS optimizando..."):
        resultados = correr_despacho_completo(
            demandas,
            año_capacidad=año_cap,
            costos_override=costos_override,
            voll=voll
        )

    # 3. Mostrar resultados
    st.subheader("📊 Resultados del Despacho")
    for s, r in resultados.items():
        if not r["exito"]:
            st.error(f"{s}: {r['error']}")
            continue

        with st.expander(f"🔌 {s} — USD {r['costo_total_usd']:,.0f}", expanded=True):
            c1, c2, c3, c4 = st.columns(4)
            pm = r["precio_marginal"]
            pm_str = f"{pm.mean():.1f}" if pm is not None else "N/A"
            shed = r["shedding_mw"].sum()

            c1.metric("Costo Total", f"${r['costo_total_usd']/1e6:.2f}M USD")
            c2.metric("Precio Marginal Prom.", f"{pm_str} USD/MWh")
            c3.metric("Load Shedding", f"{shed:.1f} MWh")
            c4.metric("Horas simuladas", f"{r['n_horas']}")

            # Gráfica de despacho
            import plotly.graph_objects as go
            fig = go.Figure()
            colores = {
                "CCGT_Gas": "#4e79a7", "Carbon": "#59a14f",
                "Fuel_Oil": "#f28e2b", "Diesel_Peaker": "#e15759",
                "Solar": "#edc948",    "Eolica": "#76b7b2",
                "Hidro": "#59a14f",    "Bateria": "#b07aa1",
            }
            for tech, vals in r["despacho"].items():
                fig.add_trace(go.Scatter(
                    y=vals, name=tech, stackgroup="gen",
                    fillcolor=colores.get(tech, "#aaa"),
                    line=dict(width=0)
                ))
            fig.add_trace(go.Scatter(
                y=r["demanda_mw"], name="Demanda",
                line=dict(color="black", width=2, dash="dash")
            ))
            fig.update_layout(
                title=f"Despacho horario — {s}",
                xaxis_title="Hora", yaxis_title="MW",
                height=350, margin=dict(t=40, b=20)
            )
            st.plotly_chart(fig, use_container_width=True)

            # Precio marginal
            if pm is not None:
                fig_pm = go.Figure()
                fig_pm.add_trace(go.Scatter(
                    y=pm, name="Precio Marginal",
                    line=dict(color="darkblue")
                ))
                fig_pm.update_layout(
                    title=f"Precio Marginal — {s}",
                    xaxis_title="Hora", yaxis_title="USD/MWh",
                    height=250, margin=dict(t=40, b=20)
                )
                st.plotly_chart(fig_pm, use_container_width=True)

else:
    st.info("👈 Configura los parámetros en el sidebar y presiona **Correr Despacho**.")
    st.markdown("""
    ### 🗺️ Sistemas disponibles
    | Sistema | Descripción | Demanda pico |
    |---------|-------------|-------------|
    | **BCS** | Baja California Sur | ~533 MW |
    | **BCA** | Baja California Norte | ~2,901 MW |
    | **SIN** | Sistema Interconectado Nacional | ~50,445 MW |

    ### 📋 Escenarios disponibles
    | Escenario | Qué simula |
    |-----------|------------|
    | ⚡ Fuel Price Shock | Gas y diésel +80% |
    | 🌞 Renewables Boom | Capacidad 2026 |
    | 🔴 Forced Outage | CCGT reducido 60% |
    | 🔋 Add Storage | Batería triplicada |
    | 📊 Scarcity Knob | VOLL duplicado |
    """)
